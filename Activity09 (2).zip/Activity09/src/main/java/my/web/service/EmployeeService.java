package my.web.service;

import java.util.List;

import my.web.entity.Employee;

public interface EmployeeService {
	boolean create(Employee emp);

	boolean update(Employee emp);

	boolean delete(int id);

	Employee view(int id);

	List<Employee> viewAll();
}
