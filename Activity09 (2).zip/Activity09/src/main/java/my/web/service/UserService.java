package my.web.service;

import my.web.entity.User;

public interface UserService {
	boolean login(String username, String password);

	boolean register(User user);
	
	User view(String username);
	
	User view(int id);
}
