package my.web.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import my.web.dao.EmployeeDao;
import my.web.entity.Employee;

@Service
public class EmployeeServiceImpt implements EmployeeService {
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	@Transactional
	public boolean create(Employee emp) {
		try {
			employeeDao.create(emp);
			return true;
		} catch (Exception e) {
			return false;
		}	
	}

	@Override
	@Transactional
	public boolean update(Employee emp) {
		try {
			employeeDao.update(emp);
			return true;
		} catch (Exception e) {
			return false;
		}	
	}

	@Override
	@Transactional
	public boolean delete(int id) {
		try {
			employeeDao.delete(id);
			return true;
		} catch (Exception e) {
			return false;
		}	
	}

	@Override
	@Transactional
	public Employee view(int id) {
		Employee employee = employeeDao.view(id);
		return employee;
	}

	@Override
	@Transactional
	public List<Employee> viewAll() {
		List<Employee> emp_list = employeeDao.viewAll();
		return emp_list;
	}

}
