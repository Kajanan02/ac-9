package my.web.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import my.web.dao.UserDao;
import my.web.entity.User;

@Service
public class UserServiceImpt implements UserService {
	@Autowired
	private UserDao userDao;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	@Transactional
	public User view(String username) {
		User user = userDao.view(username);
		return user;
	}

	@Override
	@Transactional
	public boolean login(String username, String password) {
		try {
			User user = userDao.view(username);
			if (passwordEncoder.matches(password, user.getPassword())) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	@Transactional
	public boolean register(User user) {
		try {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			userDao.create(user);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	@Override
	@Transactional
	public User view(int id) {
		try {
			User user = userDao.view(id);
			return user;
		} catch (Exception e) {
			return null;
		}
	}

}
