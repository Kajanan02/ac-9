package my.web.dao;

import my.web.entity.User;

public interface UserDao {
	User view(String username);
	
	User view(int id);

	void create(User user);
}
