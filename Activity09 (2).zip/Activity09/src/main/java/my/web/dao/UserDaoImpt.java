package my.web.dao;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import my.web.entity.User;

@Repository
public class UserDaoImpt implements UserDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public User view(String username) {
		Session currentSession = sessionFactory.getCurrentSession();
		String hql = "FROM User WHERE username = :username";
        Query<User> query = currentSession.createQuery(hql, User.class);
        query.setParameter("username", username);
		User user = query.uniqueResult();
		return user;
		
	}
	
	@Override
	public User view(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		User user = currentSession.get(User.class, id);
		return user;
		
	}

	@Override
	public void create(User user) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.save(user);
	}

}
