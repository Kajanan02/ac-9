package my.web.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import my.web.entity.Employee;

@Repository
public class EmployeeDaoImpt implements EmployeeDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void create(Employee emp) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.save(emp);		
	}

	@Override
	public void update(Employee emp) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.update(emp);
	}

	@Override
	public void delete(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		Employee emp = currentSession.get(Employee.class, id);
		if(emp != null) {
			currentSession.delete(emp);
		}
	}

	@Override
	public Employee view(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		Employee emp = currentSession.get(Employee.class, id);
		return emp;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> viewAll() {
		Session currentSession = sessionFactory.getCurrentSession();
		List<Employee> emp_list = currentSession.createQuery("from Employee").getResultList();
		return emp_list;
	}

}
