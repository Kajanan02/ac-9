package my.web.dao;

import java.util.List;

import my.web.entity.Employee;

public interface EmployeeDao {
	void create(Employee emp);

	void update(Employee emp);

	void delete(int id);

	Employee view(int id);

	List<Employee> viewAll();
}
