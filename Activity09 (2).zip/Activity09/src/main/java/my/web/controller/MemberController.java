package my.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import my.web.entity.Employee;
import my.web.entity.User;
import my.web.service.EmployeeService;
import my.web.service.UserService;

@Controller
public class MemberController {
	@Autowired
	UserService userService;

	@Autowired
	EmployeeService empService;

	@GetMapping("/home")
	public String showHome(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(true);
		int user_id = (Integer) session.getAttribute("user");
		User user = userService.view(user_id);
		model.addAttribute("user", user);
		List<Employee> emp_list = empService.viewAll();
		model.addAttribute("emp_list", emp_list);
		return "home";
	}

	@PostMapping("/create_employee")
	public String createEmployee(@ModelAttribute Employee emp, Model model) {
		empService.create(emp);
		return "redirect:/home";
	}

	@GetMapping("/edit_employee")
	public String editEmployee(@RequestParam("id") int id, Model model) {
		Employee emp = empService.view(id);
		model.addAttribute("emp", emp);
		return "employee-edit";
	}

	@PostMapping("/update_employee")
	public String updateEmployee(@ModelAttribute Employee emp, Model model) {
		empService.update(emp);
		return "redirect:/home";
	}

	@GetMapping("/delete_employee")
	public String deleteEmployee(@RequestParam("id") int id, Model model) {
		empService.delete(id);
		return "redirect:/home";
	}
}
