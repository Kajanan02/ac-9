package my.web.controller;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import my.web.entity.User;
import my.web.service.UserService;

@Controller
public class WelcomeController {
	@Autowired
	UserService userService;

	@GetMapping("/")
	public String showIndex() {
		return "index";
	}

	@GetMapping("/new")
	public String showSignUp() {
		return "sign_up";
	}

	@GetMapping("/member")
	public String showSignIn() {
		return "sign_in";
	}

	@PostMapping("/login")
	public String verifyUser(@RequestParam("username") String username,
			@RequestParam("password") String password, Model model, HttpServletRequest request) {
		if (userService.login(username, password)) {
			User user = userService.view(username);
			HttpSession session = request.getSession(true);
	        session.setAttribute("user", user.getId()); 
			return "redirect:/home";
		} else {
			model.addAttribute("msgType", "danger");
			model.addAttribute("msg", "Incorrect username or password");
			return "sign_in";
		}
	}

	@PostMapping("/register")
	public String userRegistration(@RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("email") String email, Model model) {
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		if(userService.register(user)) {
			model.addAttribute("msgType", "success");
			model.addAttribute("msg", "Registration successful. Please login to your account.");
		}else {
			model.addAttribute("msgType", "danger");
			model.addAttribute("msg", "Error occurred. Please try to register again.");
		}
		return "index";
	}
}
